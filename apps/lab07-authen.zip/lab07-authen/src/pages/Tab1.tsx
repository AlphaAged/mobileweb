import { IonPage, IonContent } from '@ionic/react';
import { useEffect, useState } from 'react';
import { authService } from '../auth/auth-service';

const Tab1: React.FC = () => {

  const [user, setUser] = useState<any | null>(null);

  useEffect(() => {
    authService.getCurrentUser().then(setUser);
  }, []);

  return (
    <IonPage>
      <IonContent className="ion-padding">

        <h2>User Info</h2>

        {user && (
          <>
            <p>UID: {user.uid}</p>
            <p>Email: {user.email}</p>
            <p>Phone: {user.phoneNumber}</p>
            <p>Name: {user.displayName}</p>
          </>
        )}

      </IonContent>
    </IonPage>
  );
};

export default Tab1;
