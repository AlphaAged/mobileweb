import { Redirect, Route } from 'react-router-dom';
import { IonApp, IonRouterOutlet } from '@ionic/react';
import { IonReactRouter } from '@ionic/react-router';
import { useEffect, useState } from 'react';
import Tabs from './pages/Tab1';
import LoginPage from './pages/loginPage';
import { authService } from './auth/auth-service';
import { onAuthStateChanged } from 'firebase/auth';
import EmailLoginPage from './pages/EmailLoginPage';
import GoogleLoginPage from './pages/GoogleLoginPage';
import PhoneLoginPage from './pages/PhoneLoginPage';




const App: React.FC = () => {

  const [user, setUser] = useState<any>(undefined);

  useEffect(() => {
    return () => unsubscribe();
  }, []);

  if (user === undefined) return null;

  return (
    <IonApp>
      <IonReactRouter>
        <IonRouterOutlet>

          <Route path="/login" exact>
            {user ? <Redirect to="/tabs/tab1" /> : <LoginPage />}
          </Route>

          <Route path="/tabs">
            {user ? <Tabs /> : <Redirect to="/login" />}
          </Route>

          <Route exact path="/">
            <Redirect to="/tabs/tab1" />
          </Route>
          <Route path="/login-email" component={EmailLoginPage} exact />
          <Route path="/login-google" component={GoogleLoginPage} exact />
          <Route path="/login-phone" component={PhoneLoginPage} exact />


        </IonRouterOutlet>
      </IonReactRouter>
    </IonApp>
  );
};

export default App;